﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Tennis
{
    public partial class Scoreboard : Form
    {
        private int _advantage;

        public int Advantage
        {
            get { return _advantage; }
            set { _advantage = value; }
        }

        private int _player1Score;

        public int Player1Score
        {
            get { return _player1Score; }
            set { _player1Score = value; }
        }

        private int _player2Score;

        public int Player2Score
        {
            get { return _player2Score; }
            set { _player2Score = value; }
        }


        public Scoreboard()
        {
            InitializeComponent();
        }

        public Scoreboard(string player1, string player2)
        {
            InitializeComponent();
            this.Player1label.Text = player1;
            this.Player2Label.Text = player2;
            this.textBox1.Text = this.textBox2.Text = "0";
            this.setplayer1textBox.Text = this.setplayer2textBox.Text = "0";
            this.display.Text = "";
            Player1Score = Player2Score = 0;
            Advantage = 0;

        }

        /// <summary>
        /// Win point function
        /// </summary>
        /// <param name="player">player id</param>
        /// <param name="score">player score</param>
        private void WinPoint(TextBox player, int playerId)
        {
            switch (player.Text)
            {
                case "0":
                    player.Text = "15";
                    break;
                case "15":
                    player.Text = "30";
                    break;
                case "30":
                    player.Text = "40";
                    break;
                case "40":
                    WinGame(playerId);
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WinPoint(this.textBox1, 1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            WinPoint(this.textBox2, 2);
        }

        /// <summary>
        /// Win game output
        /// </summary>
        /// <param name="playerName">Player</param>
        private void WinGameMsg(string playerName)
        {
            MessageBox.Show(playerName + " win the game !");
            this.textBox1.Text = this.textBox2.Text = "0";
        }

        /// <summary>
        /// Chech advantage function
        /// </summary>
        /// <param name="player">Player id</param>
        /// <param name="playerName">Player Name</param>
        private void CheckAdvantage(int player, string playerName)
        {
            switch (Advantage)
            {
                case 0:
                    this.display.Text = "Advantage : " + playerName + " !";
                    Advantage = player;
                    break;
                case 1:
                case 2:
                    if (Advantage == player)
                    {
                        if (Advantage == 1)
                        {
                            Player1Score++;
                            this.setplayer1textBox.Text = Player1Score.ToString();
                        }
                        else
                        {
                            Player2Score++;
                            this.setplayer2textBox.Text = Player2Score.ToString();
                        }
                        Advantage = 0;
                        if (Player1Score >= 6 || Player2Score >= 6)
                            WinMatch();

                        WinGameMsg(playerName);
                        this.display.Text = "";
                        break;
                    }
                    else
                    {
                        this.display.Text = "DEUCE !";
                        Advantage = 0;
                        break;
                    }
            }
        }

        /// <summary>
        /// Game management function
        /// </summary>
        /// <param name="player">Player id</param>
        private void WinGame(int player)
        {
            string playerName;
            if (player == 1)
                playerName = this.Player1label.Text;
            else
                playerName = this.Player2Label.Text;

            if ((this.textBox1.Text != this.textBox2.Text))
            {
                WinGameMsg(playerName);
                if (player == 1)
                {
                    Player1Score++;
                    this.setplayer1textBox.Text = Player1Score.ToString();
                }
                else
                {
                    Player2Score++;
                    this.setplayer2textBox.Text = Player2Score.ToString();
                }
                Advantage = 0;
                if (Player1Score >= 6 || Player2Score >= 6)
                    WinMatch();
                return;
            }
            CheckAdvantage(player, playerName);
        }

        /// <summary>
        /// End prograrm
        /// </summary>
        /// <param name="winner">Player winner</param>
        private void EndProgram(string winner)
        {
            MessageBox.Show(winner + " win the match !!!");
            System.Environment.Exit(1);
        }


        /// <summary>
        /// Check win matcn
        /// </summary>
        private void WinMatch()
        {
            if ((Player1Score >= 6 && Player2Score <= 4) || Player1Score == 7)
            {
                EndProgram(this.Player1label.Text);
            }

            if ((Player2Score >= 6 && Player1Score <= 4) || Player2Score == 7)
            {
                EndProgram(this.Player2Label.Text);
            }
        }

    }
}
