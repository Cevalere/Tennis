﻿namespace Tennis
{
    partial class SetPlayers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SetPlayersOkButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Player1_textBox = new System.Windows.Forms.TextBox();
            this.Player2textbox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // SetPlayersOkButton
            // 
            this.SetPlayersOkButton.Location = new System.Drawing.Point(121, 164);
            this.SetPlayersOkButton.Name = "SetPlayersOkButton";
            this.SetPlayersOkButton.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.SetPlayersOkButton.Size = new System.Drawing.Size(75, 23);
            this.SetPlayersOkButton.TabIndex = 0;
            this.SetPlayersOkButton.Text = "Go";
            this.SetPlayersOkButton.UseVisualStyleBackColor = true;
            this.SetPlayersOkButton.Click += new System.EventHandler(this.SavePlayersClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Player 1 :";
            // 
            // Player1_textBox
            // 
            this.Player1_textBox.Location = new System.Drawing.Point(76, 70);
            this.Player1_textBox.Name = "Player1_textBox";
            this.Player1_textBox.Size = new System.Drawing.Size(196, 20);
            this.Player1_textBox.TabIndex = 3;
            // 
            // Player2textbox
            // 
            this.Player2textbox.Location = new System.Drawing.Point(76, 120);
            this.Player2textbox.Name = "Player2textbox";
            this.Player2textbox.Size = new System.Drawing.Size(196, 20);
            this.Player2textbox.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(55, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(206, 24);
            this.label3.TabIndex = 5;
            this.label3.Text = "Enter player\'s names";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 123);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Player 2 :";
            // 
            // SetPlayers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(293, 213);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Player2textbox);
            this.Controls.Add(this.Player1_textBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SetPlayersOkButton);
            this.MaximizeBox = false;
            this.Name = "SetPlayers";
            this.ShowIcon = false;
            this.Text = "Tennis Scoreboard";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button SetPlayersOkButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Player1_textBox;
        private System.Windows.Forms.TextBox Player2textbox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}