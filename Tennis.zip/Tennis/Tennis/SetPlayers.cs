﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Tennis
{
    public partial class SetPlayers : Form
    {
        public SetPlayers()
        {
            InitializeComponent();
        }

        private void SavePlayersClick(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(Player1_textBox.Text) || String.IsNullOrEmpty(Player2textbox.Text))
                MessageBox.Show("Players' names is empty");
            else
            {
                this.Hide();
                Scoreboard scoreboard = new Scoreboard(Player1_textBox.Text,Player2textbox.Text);
                scoreboard.Show();

            }

        }

    }
}
