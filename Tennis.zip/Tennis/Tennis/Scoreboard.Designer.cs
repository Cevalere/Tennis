﻿namespace Tennis
{
    partial class Scoreboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Player1label = new System.Windows.Forms.Label();
            this.Player2Label = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.display = new System.Windows.Forms.Label();
            this.setplayer1textBox = new System.Windows.Forms.TextBox();
            this.setplayer2textBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Player1label
            // 
            this.Player1label.AutoSize = true;
            this.Player1label.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player1label.Location = new System.Drawing.Point(51, 21);
            this.Player1label.Name = "Player1label";
            this.Player1label.Size = new System.Drawing.Size(85, 24);
            this.Player1label.TabIndex = 0;
            this.Player1label.Text = "Player 1";
            // 
            // Player2Label
            // 
            this.Player2Label.AutoSize = true;
            this.Player2Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player2Label.Location = new System.Drawing.Point(271, 21);
            this.Player2Label.Name = "Player2Label";
            this.Player2Label.Size = new System.Drawing.Size(85, 24);
            this.Player2Label.TabIndex = 2;
            this.Player2Label.Text = "Player 2";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(26, 62);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(132, 107);
            this.textBox1.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(246, 62);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(131, 107);
            this.textBox2.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(55, 187);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 5;
            this.button1.Text = "Add Point !";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(275, 187);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 6;
            this.button2.Text = "Add Point ! ";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // display
            // 
            this.display.AutoSize = true;
            this.display.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.display.ForeColor = System.Drawing.Color.RoyalBlue;
            this.display.Location = new System.Drawing.Point(25, 227);
            this.display.Name = "display";
            this.display.Size = new System.Drawing.Size(111, 31);
            this.display.TabIndex = 7;
            this.display.Text = "Display";
            // 
            // setplayer1textBox
            // 
            this.setplayer1textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.setplayer1textBox.Location = new System.Drawing.Point(64, 276);
            this.setplayer1textBox.Multiline = true;
            this.setplayer1textBox.Name = "setplayer1textBox";
            this.setplayer1textBox.Size = new System.Drawing.Size(51, 69);
            this.setplayer1textBox.TabIndex = 8;
            // 
            // setplayer2textBox
            // 
            this.setplayer2textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.setplayer2textBox.Location = new System.Drawing.Point(288, 276);
            this.setplayer2textBox.Multiline = true;
            this.setplayer2textBox.Name = "setplayer2textBox";
            this.setplayer2textBox.Size = new System.Drawing.Size(51, 69);
            this.setplayer2textBox.TabIndex = 9;
            // 
            // Scoreboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(402, 387);
            this.Controls.Add(this.setplayer2textBox);
            this.Controls.Add(this.setplayer1textBox);
            this.Controls.Add(this.display);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Player2Label);
            this.Controls.Add(this.Player1label);
            this.MaximizeBox = false;
            this.Name = "Scoreboard";
            this.ShowIcon = false;
            this.Text = "Tennis Scoreboard";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Player1label;
        private System.Windows.Forms.Label Player2Label;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label display;
        private System.Windows.Forms.TextBox setplayer1textBox;
        private System.Windows.Forms.TextBox setplayer2textBox;
    }
}